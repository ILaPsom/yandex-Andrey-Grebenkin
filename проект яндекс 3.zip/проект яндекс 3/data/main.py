import os
import logging
from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command
from aiogram.types import Message
from aiogram.utils.keyboard import ReplyKeyboardBuilder
from sqlalchemy import create_engine, Column, Integer, String, JSON
from sqlalchemy.orm import sessionmaker, declarative_base
import aiohttp
import json

# Настройка логгирования
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

# Инициализация базы данных
Base = declarative_base()


class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, unique=True)
    language = Column(String, default=None)
    vocabulary = Column(JSON, default=lambda: {})


engine = create_engine('sqlite:///user_data.db', echo=True)
Base.metadata.create_all(engine)
Session = sessionmaker(bind=engine)

bot = Bot(token="7449187472:AAH79dw5h-LqYQ8ZzXtHqKC0_bNlIACvYco")
dp = Dispatcher()


def get_language_keyboard():
    builder = ReplyKeyboardBuilder()
    builder.add(types.KeyboardButton(text="🇬🇧 Английский"))
    builder.add(types.KeyboardButton(text="🇩🇪 Немецкий"))
    builder.add(types.KeyboardButton(text="🇫🇷 Французский"))
    builder.add(types.KeyboardButton(text="🇪🇸 Испанский"))
    builder.adjust(2)
    return builder.as_markup(resize_keyboard=True)


async def translate_text(text: str, source_lang: str) -> str:
    lang_map = {
        "🇬🇧 Английский": "en",
        "🇩🇪 Немецкий": "de",
        "🇫🇷 Французский": "fr",
        "🇪🇸 Испанский": "es"
    }
    source_code = lang_map.get(source_lang, "en")

    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                    "https://api.mymemory.translated.net/get",  # Исправлено: убран пробел
                    params={
                        "q": text,
                        "langpair": f"{source_code}|ru",
                        "de": "ILaPsom@yandex.ru"
                    }
            ) as resp:
                data = await resp.json()
                if resp.status != 200:
                    logger.error(f"API Error: {resp.status} - {data}")
                    return f"Ошибка перевода (код {resp.status})"
                return data.get('responseData', {}).get('translatedText', text)
    except Exception as e:
        logger.error(f"Translation error: {e}")
        return f"Ошибка соединения: {str(e)}"


@dp.message(Command("start"))
async def cmd_start(message: Message):
    await message.answer(
        "👋 Привет!\n"
        "У меня есть команда /vocabulary с помощью которой можно открыть словарь.\n"
        "Выбери язык для перевода:",
        reply_markup=get_language_keyboard()
    )


@dp.message(F.text.in_(["🇬🇧 Английский", "🇩🇪 Немецкий", "🇫🇷 Французский", "🇪🇸 Испанский"]))
async def set_language(message: Message):
    session = Session()
    try:
        user = session.query(User).filter_by(user_id=message.from_user.id).first()

        if not user:
            user = User(user_id=message.from_user.id, language=message.text)
            session.add(user)
        else:
            user.language = message.text

        session.commit()
        await message.answer(
            f"✅ Выбран язык: {message.text}. Отправь мне слова или фразы для перевода!",
            reply_markup=types.ReplyKeyboardRemove()
        )
    except Exception as e:
        logger.error(f"DB error: {e}")
        await message.answer("⚠️ Ошибка сохранения языка")
    finally:
        session.close()


@dp.message(F.text & ~F.text.startswith('/'))
async def handle_text(message: Message):
    session = Session()
    try:
        user = session.query(User).filter_by(user_id=message.from_user.id).first()

        if not user or not user.language:
            await message.answer("Сначала выбери язык через /start")
            return

        translated = await translate_text(message.text, user.language)
        await message.answer(f"🔤 Перевод: {translated}")

        if user.vocabulary is None:
            user.vocabulary = {}

        words = message.text.split()
        if len(words) == 1:
            current_vocab = user.vocabulary.copy()
            current_vocab[message.text] = translated
            user.vocabulary = current_vocab
            session.commit()
            await message.answer(f"💾 Слово '{message.text}' добавлено в словарь!")

    except Exception as e:
        logger.error(f"Error: {e}")
        await message.answer("⚠️ Ошибка при обработке запроса")
    finally:
        session.close()


@dp.message(Command("vocabulary"))
async def show_vocabulary(message: Message):
    session = Session()
    try:
        user = session.query(User).filter_by(user_id=message.from_user.id).first()

        if not user or not user.vocabulary:
            await message.answer("📭 Словарь пуст")
            return

        vocab = user.vocabulary if isinstance(user.vocabulary, dict) else json.loads(user.vocabulary)

        if not vocab:
            await message.answer("📭 Словарь пуст")
            return

        vocab_text = "\n".join([f"• {word} → {trans}" for word, trans in vocab.items()])
        await message.answer(f"📚 Твой словарь:\n{vocab_text}")

    except Exception as e:
        logger.error(f"Vocab error: {e}")
        await message.answer("⚠️ Ошибка при загрузке словаря")
    finally:
        session.close()


async def main():
    await dp.start_polling(bot)


if __name__ == "__main__":
    import asyncio

    asyncio.run(main())