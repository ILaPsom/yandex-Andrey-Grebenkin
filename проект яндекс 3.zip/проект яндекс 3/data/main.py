import os
import logging
from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command
from aiogram.types import Message
from aiogram.utils.keyboard import ReplyKeyboardBuilder
from sqlalchemy import create_engine, Column, Integer, String, JSON
from sqlalchemy.orm import sessionmaker, declarative_base
import aiohttp
import json

# Настройка логгирования для вывода информации в консоль
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

# Создание базовой модели для ORM (SQLAlchemy)
Base = declarative_base()


# Определение модели пользователя в базе данных
class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True)  # Уникальный ID записи
    user_id = Column(Integer, unique=True)  # Telegram ID пользователя
    language = Column(String, default=None)  # Выбранный язык перевода
    vocabulary = Column(JSON, default=lambda: {})  # Словарь пользователя в формате JSON


# Подключение к базе данных SQLite и создание таблиц
engine = create_engine('sqlite:///user_data.db', echo=True)
Base.metadata.create_all(engine)
Session = sessionmaker(bind=engine)

# Инициализация бота с токеном
bot = Bot(token="BOT_TOKEN")
dp = Dispatcher()  # Диспетчер для обработки сообщений


# Функция для создания клавиатуры выбора языка
def get_language_keyboard():
    builder = ReplyKeyboardBuilder()
    builder.add(types.KeyboardButton(text="🇬🇧 Английский"))
    builder.add(types.KeyboardButton(text="🇩🇪 Немецкий"))
    builder.add(types.KeyboardButton(text="🇫🇷 Французский"))
    builder.add(types.KeyboardButton(text="🇪🇸 Испанский"))
    builder.adjust(2)  # Расположить по две кнопки в ряд
    return builder.as_markup(resize_keyboard=True)


# Асинхронная функция перевода текста через MyMemory API
async def translate_text(text: str, source_lang: str) -> str:
    lang_map = {
        "🇬🇧 Английский": "en",
        "🇩🇪 Немецкий": "de",
        "🇫🇷 Французский": "fr",
        "🇪🇸 Испанский": "es"
    }
    source_code = lang_map.get(source_lang, "en")  # Получаем код языка

    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                    "https://api.mymemory.translated.net/get ",
                    params={
                        "q": text,  # Текст для перевода
                        "langpair": f"{source_code}|ru",  # Переводим на русский
                        "de": "ILaPsom@yandex.ru"  # Email учетной записи API
                    }
            ) as resp:
                data = await resp.json()
                return data.get('responseData', {}).get('translatedText', text)
    except Exception as e:
        logger.error(f"Ошибка перевода: {e}")
        return text


# Обработчик команды /start
@dp.message(Command("start"))
async def cmd_start(message: Message):
    await message.answer(
        "👋 Привет!\n"
        "У меня есть команда /vocabulary с помощью которой можно открыть словарь.\n"
        "Выбери язык для перевода:",
        reply_markup=get_language_keyboard()
    )


# Обработчик выбора языка через нажатие кнопки
@dp.message(F.text.in_(["🇬🇧 Английский", "🇩🇪 Немецкий", "🇫🇷 Французский", "🇪🇸 Испанский"]))
async def set_language(message: Message):
    session = Session()  # Открываем сессию БД
    try:
        # Проверяем, есть ли пользователь в БД
        user = session.query(User).filter_by(user_id=message.from_user.id).first()

        if not user:
            # Если нет — создаём нового пользователя
            user = User(user_id=message.from_user.id, language=message.text)
            session.add(user)
        else:
            # Если есть — обновляем его язык
            user.language = message.text

        session.commit()  # Сохраняем изменения
        await message.answer(
            f"✅ Выбран язык: {message.text}. Отправь мне слова или фразы для перевода!",
            reply_markup=types.ReplyKeyboardRemove()  # Убираем клавиатуру
        )
    except Exception as e:
        logger.error(f"Ошибка работы с БД: {e}")
        await message.answer("⚠️ Ошибка сохранения языка")
    finally:
        session.close()  # Закрываем сессию


# Обработка обычных текстовых сообщений (слова/фразы)
@dp.message(F.text & ~F.text.startswith('/'))
async def handle_text(message: Message):
    session = Session()
    try:
        user = session.query(User).filter_by(user_id=message.from_user.id).first()

        if not user or not user.language:
            await message.answer("Сначала выбери язык через /start")
            return

        # Переводим текст
        translated = await translate_text(message.text, user.language)
        await message.answer(f"🔤 Перевод: {translated}")

        # Инициализируем словарь, если он не существует
        if user.vocabulary is None:
            user.vocabulary = {}

        words = message.text.split()
        if len(words) == 1:  # Сохраняем только одиночные слова
            current_vocab = user.vocabulary.copy()
            current_vocab[message.text] = translated
            user.vocabulary = current_vocab
            session.commit()
            await message.answer(f"💾 Слово '{message.text}' добавлено в словарь!")

    except Exception as e:
        logger.error(f"Ошибка: {e}")
        await message.answer("⚠️ Ошибка при обработке запроса")
    finally:
        session.close()


# Обработчик команды /vocabulary — показывает содержимое словаря
@dp.message(Command("vocabulary"))
async def show_vocabulary(message: Message):
    session = Session()
    try:
        user = session.query(User).filter_by(user_id=message.from_user.id).first()

        if not user or not user.vocabulary:
            await message.answer(".FileNotFoundException")
            return

        vocab = user.vocabulary if isinstance(user.vocabulary, dict) else json.loads(user.vocabulary)

        if not vocab:
            await message.answer(" FileNotFoundException")
            return

        vocab_text = "\n".join([f"• {word} → {trans}" for word, trans in vocab.items()])
        await message.answer(f"📚 Твой словарь:\n{vocab_text}")

    except Exception as e:
        logger.error(f"Ошибка загрузки словаря: {e}")
        await message.answer("⚠️ Ошибка при загрузке словаря")
    finally:
        session.close()


# Запуск бота
async def main():
    await dp.start_polling(bot)


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())